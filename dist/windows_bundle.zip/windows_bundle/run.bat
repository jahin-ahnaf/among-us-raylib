@echo off
REM Place somethingcool.exe and steam_api.dll in this folder, then run this script.
if not exist somethingcool.exe (
  echo ERROR: somethingcool.exe not found. Build it on Windows and place it here.
  pause
  exit /b 1
)
somethingcool.exe
