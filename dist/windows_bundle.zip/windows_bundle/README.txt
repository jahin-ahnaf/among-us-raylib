Windows bundle notes:
- This bundle contains only game resources and steam_appid.txt.
- You MUST add a Windows-built somethingcool.exe (matching architecture) and steam_api.dll.
- To build on Windows:
  * Use MSVC or MinGW and link against raylib and the Steamworks import library.
  * Include the Steam redistributable steam_api.dll next to the .exe.
- To test locally on Windows, run Steam, log in, and run somethingcool.exe.
